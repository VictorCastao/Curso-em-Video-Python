def metade(valor):
    return moeda(valor / 2)


def dobro(valor):
    return moeda(valor * 2)


def aumentar(valor, taxa):
    return moeda(valor * (100 + taxa) / 100)


def diminuir(valor, taxa):
    return moeda(valor * (100 - taxa) / 100)


# Função inicial
"""
def moeda(numero):
    texto = str(round(numero, 2))
    resp = ""
    contador = 0
    virgula = False
    for char in texto:
        if char == '.':
            resp += ','
            virgula = True
            continue
        else:
            resp += char
        if virgula == True:
            contador += 1
    if contador == 0:
        resp += ',00'
    elif contador == 1:
        resp += '0'
    return resp
"""


# Função otimizada
def moeda(numero):
    return f'{numero:.2f}'.replace('.', ',')
