def metade(valor):
    return valor / 2


def dobro(valor):
    return valor * 2


def aumentar(valor, taxa):
    return valor * (100 + taxa) / 100


def diminuir(valor, taxa):
    return valor * (100 - taxa) / 100
