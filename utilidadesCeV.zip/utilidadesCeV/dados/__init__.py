def leiaDinheiro(txt):
    while True:
        msg = '\033[0;31mErro! Entrada Inválida!\033[m'
        print(txt, end='')
        numero = input().strip().replace(',', '.')
        if numero.isalpha() or numero == "":
            print(msg)
            continue
        break
    return float(numero)
