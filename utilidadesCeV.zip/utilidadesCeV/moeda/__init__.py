def metade(valor, formatar=False):
    if formatar:
        return moeda(valor / 2)
    return valor / 2


def dobro(valor, formatar=False):
    if formatar:
        return moeda(valor * 2)
    return valor * 2


def aumentar(valor, taxa, formatar):
    if formatar:
        return moeda(valor * (100 + taxa) / 100)
    return valor * (100 + taxa) / 100


def diminuir(valor, taxa, formatar):
    if formatar:
        return moeda(valor * (100 - taxa) / 100)
    return valor * (100 - taxa) / 100


def moeda(numero):
    return f'{numero:.2f}'.replace('.', ',')


def resumo(unidade, valor, aumenta, diminui, formatar=True):
    met = unidade + " " + str(metade(valor,formatar))
    dob = unidade + " " + str(dobro(valor,formatar))
    aum = unidade + " " + str(aumentar(valor, aumenta, formatar))
    dim = unidade + " " + str(diminuir(valor, diminui, formatar))
    print('=' * 30)
    print(f'{"RESUMO":^30}')
    print('=' * 30)
    print(f'Metade: {met}')
    print(f'Dobro: {dob}')
    print(f'Aumentar {aumenta}%: {aum}')
    print(f'Diminuir {diminui}%: {dim}')
    print('=' * 30)
